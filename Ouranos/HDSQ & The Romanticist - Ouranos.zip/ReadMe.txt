This original composition was created entirely by The Romanticist and HDSQ.

If you decide to reupload this creation, you must:
 - Provide proper credit to the creators of this content.
 - Provide a link to both of our original videos in your video description.

You may:
 - Reupload this content in your own video, provided that the above rules 
    are followed.
 - Modify the MIDI file for personal use, and upload a video of the edited 
    version, provided that you state that the MIDI has been modified from its 
    original form. (Subject to rules below).

You may NOT:
 - Steal artwork or phrases from this work for use in your own, even if credit 
    is given.
 - Redistribute any modified versions of this MIDI file without written 
    permission. Upoading videos of the modified version is OK (Subject 
    to rules above).
 - Attempt to pass off this creation as your own.

HDSQ and The Romanticist reserve the right to partial monetisation 
of any published videos of this MIDI file (if they go viral or something).

To enquire about any information listed here, please message me on Discord (HDSQ#2154)